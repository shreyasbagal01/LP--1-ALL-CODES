using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TE02;

namespace TE0
{
class Program{
       static void Main(string[] args) {

            Console.WriteLine(functions.Add(4, 10));

            Console.WriteLine(functions.sub(4, 2));

            Console.WriteLine(functions.mul(4, 10));

            Console.WriteLine(functions.div(4, 2));

            Console.ReadKey();
        }
    }
}
