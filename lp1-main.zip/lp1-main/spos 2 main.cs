using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TE02
{
public static class functions
    {
    public static int Add(int n1, int n2)
        {
            return n1 + n2;

        }
    public static int sub(int n1, int n2)
        {
            return n1 - n2;

        }
    public static int mul(int n1, int n2)
        {
            return n1 * n2;

        }
    public static int div(int n1, int n2)
        {
            return n1 / n2;

        }
    }
}
